<meta name="Unblocked, unblocker, school games, Youtube, Discord, ubg365, unblocked games 76, classroom 6x, unblocked games wtf, unblocked games, cookie clicker, school work, keyword, school fun, GitHub, coolmathgames, free download, apk, html, index.html, discord, youtube, videos, free, hacked, iframe, google snake, Minecraft, blockblast, block blast, Mario, smash carts, unblocked games free 76 classroom 6x google sites, google sites, google site, chromebook hack" content="nblocked games on GitHub – bypass GoGuardian, Securly, and iboss. Play Cookie Clicker, UBG365, Unblocked Games 76, Classroom 6x, Google Snake, Minecraft, BlockBlast, Smash Carts, and more on Chromebook. Free downloads, HTML files, iframe hacks, and proxies.">

<meta name="description" content="goguardianbypass, securly-bypass Unblocked, Discord, Youtube, unblocker, ubg365, unblocked games 76, classroom 6x, unblocked games wtf, unblocked games, cookie clicker, school work, keyword, school fun, GitHub, coolmathgames, free download, apk, html, index.html, discord, youtube, videos, free, hacked, iframe, google snake, Minecraft, blockblast, block blast, Mario, smash carts, unblocked games free 76 classroom 6x google sites, google sites, google site, rammerhead, nettleweb, chromebook-hack,">
<meta name="Unblocked Games And apps free discord bypass school games" content="goguardianbypass, securly-bypass Unblocked, Discord, Youtube, unblocker, ubg365, unblocked games 76, classroom 6x, unblocked games wtf, unblocked games, cookie clicker, school work, keyword, school fun, GitHub, coolmathgames, free download, apk, html, index.html, discord, youtube, videos, free, hacked, iframe, google snake, Minecraft, blockblast, block blast, Mario, smash carts, unblocked games free 76 classroom 6x google sites, google sites, google site, rammerhead, nettleweb, chromebook-hack,">
<meta name="unblocked games search terms" content="goguardianbypass, securly-bypass Unblocked, Discord, Youtube, unblocker, ubg365, unblocked games 76, classroom 6x, unblocked games wtf, unblocked games, cookie clicker, school work, keyword, school fun, GitHub, coolmathgames, free download, apk, html, index.html, discord, youtube, videos, free, hacked, iframe, google snake, Minecraft, blockblast, block blast, Mario, smash carts, keyword, unblocked games free 76 classroom 6x google sites, google sites, google site, rammerhead, nettleweb, chromebook-hack,">

![40+ unblocked games unblocked cookie clicker discord youtube unblocker](https://github.com/FurtiveThomas/Unbore_Yourself_in_School/blob/main/1%20Unblocked%20Games/%EF%BC%9FCookie%20Clicker%202.054%20(100%25)/Cookie%20Clicker/img/pixel.png)
# READ THIS
# Unblocked Games Github 
* Welcome to my Unblocked Games Github repository! Here you can access and enjoy a variety of games and apps in school/work where sites are restricted.
* In this repository, you will find a downloadable Html file that provides access to unblocked games and apps.

## Usage
* [DOWNLOAD HERE](https://github.com/FurtiveThomas/Unbore_Yourself_in_School/archive/refs/heads/main.zip)
* To start playing Unblocked Games Github, you can download the apps/games from the link provided below.

## Instructions
* Download the html files from the link above.
* Launch the app/game on your computer.
* Star And Fork This repository
* Share to your friends

## Popular Games List  
- Cookie Clicker Unblocked
- Google Snake Unblocked 
- No Wifi Chrome Game Unblocked 
- Wordle
  
### Further Information
* To open something double clicking the index.html or the only .html file to run the software you want
* ALL made/unblocked BY Skidkid420/FurtiveThomas/Kry
* If something has a " ！" at the start of a it means I made said thing.
* If something has a " ？" it means it is something that was made already and I unblocked said thing.
* If something has a " % " and some numbers that is the chance of said thing being unblocked. 
* Put games you want in the [issues tab](https://github.com/FurtiveThomas/Unbore_Yourself_in_School/issues/new?template=add-.md)/[discussions tab](https://github.com/FurtiveThomas/Unbore_Yourself_in_School/discussions/4) and I will try my best to add them
* My Youtube if there is any doubters: https://www.youtube.com/@%CE%99%CE%9E%CE%9E%CE%99 

## Partners
### UnblockZone
* [Unblocked Zone Website](https://unblockzone.github.io/)
* [Unblocked Zone Discord](https://discord.gg/XRkQyY2Hhy)

### Pickle
* [Discord](https://discord.gg/8wxSWySa)

### Your Spot Here
* Contact me on discord: skibkid420





